#include <stdio.h>
#include "struct.h"

command comm[258];
data d[258];
int result;
int num;
int dPageSize;
void DM(){
	if(num >= 2 && comm[num].nop == 0 && (comm[num].MemRead == 1 || comm[num].MemWrite == 1)){
		result = reg[comm[num].rs] + comm[num].C;
		int dnum = result/4 + 2;
		d[dnum].address = d[0].address + 4*(dnum-2);
		d[dnum].VPN = d[dnum].address/dPageSize;
		int TLBhit = Find_dTLB(dnum);
		int PThit = 0;
		//TLB miss
                if(TLBhit == 0){
                        PThit = Find_dPT(dnum);
                        //PT miss
                        if(PThit == 0){
                                New_dMem(dnum);
                                New_dPT(dnum);
                                //fprintf(trace," Disk ");
                        }
                        else{
                                d[dnum].PA = (d[dnum].PPN * 4) + d[dnum].offset;
                                dCache(dnum);
                                //fprintf(trace," DPT ");
                        }
                        New_dTLB(dnum);
                        dCache(dnum);
                }
                else{
                        d[dnum].PA = (d[dnum].PPN * 4) + d[dnum].offset;
                        //fprintf(trace," DTLB ");
                        dCache(dnum);
                }
		if(TLBhit == 1) fprintf(trace, " DTLB ");
		else if(PThit == 0) fprintf(trace, " Disk ");
		else fprintf(trace, " DPageTAble ");

		switch(comm[num].opcode){
			case 35: //lw
				result = d[result/4 + 2].value;
//				printf("lw:0x%08X\n",result);
			break;

			case 33: //lh
				if(result % 4 == 0) //upper
                                      	result = d[result/4 + 2].value >> 16;
				else if(result % 4 == 2) //lower
					result = (d[result/4 + 2].value << 16) >> 16;
				if((result >> 15) == 1)
					result = 0xffff0000 | result;        
				break;

			case 37: //lhu
			 	if(result % 4 == 0) //upper
                                        result = d[result/4 + 2].value >> 16;
                                else if(result % 4 == 2) //lower
                                        result = (d[result/4 + 2].value << 16) >> 16;
			break;
	
			case 32: //lb
				if(result % 4 == 0) //24-32 bits
					result = d[result/4 + 2].value >> 24;
				else if(result % 4 == 1) //16-24 bits
					result = (d[result/4 + 2].value << 8) >> 24;
				else if(result % 4 == 2) //8-16 bits	
					result = (d[result/4 + 2].value << 16) >> 24;
				else //0-8 bits
					 result = (d[result/4 + 2].value << 24) >> 24;

				if((result >> 7) == 1)
					result = 0xffffff00 | result;				
			break;

			case 36: //lbu
			        if(result % 4 == 0) //24-32 bits
                                        result = d[result/4 + 2].value >> 24;
                                else if(result % 4 == 1) //16-24 bits
                                        result = (d[result/4 + 2].value << 8) >> 24;
                                else if(result % 4 == 2) //8-16 bits
                                        result = (d[result/4 + 2].value << 16) >> 24;
                                else //0-8 bits
                                        result = (d[result/4 + 2].value << 24) >> 24;
                         	
			break;

			case 43: //sw
				d[result/4 + 2].value = reg[comm[num].rt];
			break;

			case 41: //sh
				if(result % 4 == 0) //upper
                                   	d[result/4 + 2].value = ((reg[comm[num].rt]  & 0x0000FFFF) << 16) | ((d[result/4 + 2].value << 16) >> 16);
                                else if(result % 4 == 2) //lower
                                        d[result/4 + 2].value = (reg[comm[num].rt] & 0x0000FFFF) | ((d[result/4 + 2].value >> 16) << 16);
			break;

			case 40: //sb
				if(result % 4 == 0) //save 24-32 bit
                        		d[result/4+2].value = (reg[comm[num].rt] & 0X000000FF) << 24 | (d[result/4+2].value & 0X00FFFFFF);                
				else if(result % 4 == 1) //save 16-24 bit
                       			d[result/4+2].value = (reg[comm[num].rt] & 0X000000FF) << 16 | (d[result/4+2].value & 0XFF00FFFF);
                		else if(result % 4 == 2) //save 8-16 bit
                       			d[result/4+2].value = (reg[comm[num].rt] & 0X000000FF) << 8 | (d[result/4+2].value & 0XFFFF00FF);
                		else  //save 0-8 bit
                       			d[result/4+2].value = (reg[comm[num].rt] & 0X000000FF) | (d[result/4+2].value & 0XFFFFFF00);
			break;
		}
	}
}
