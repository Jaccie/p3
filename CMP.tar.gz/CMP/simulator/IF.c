#include <stdio.h>
#include "struct.h"
unsigned int PC;
int num;
int isHalt;
command comm[258];
FILE* trace;

void IF(){
		fprintf(trace,":");
		int TLBhit = Find_iTLB();
		int PThit = 0;
	//	printf("TLB\n");	
		//TLB miss
		if(TLBhit == 0){
			int PThit = Find_iPT();
	//		printf("PAge\n");
			//PT miss
			if(PThit == 0){
				New_iMem();
				New_iPT();
	//			printf("Miss\n");
				//fprintf(trace," Disk ");
			}
			else{ 
				comm[num].PA = (comm[num].PPN * 4) + comm[num].offset;
				//fprintf(trace, " IPageTable  ");
			}
			New_iTLB();
	//		printf("NEwTLB\n");
			iCache();
	//		printf("Cache\n");
		}
		else{
			comm[num].PA = (comm[num].PPN * 4) + comm[num].offset;
		 	//fprintf(trace,": ITLB  ");
			iCache();
		}
		//compute PA
		//if instruction is halt
		if(comm[num].instruction >> 26 == 63){
			isHalt = 1;
			halt();
		}
		if(TLBhit == 1) fprintf(trace," ITLB  ");
		else if(PThit == 0) fprintf(trace," Disk  ");
		else fprintf(trace, " IPageTable  ");
		fprintf(trace, "; ");
	//	printf("Finish\n");
}

