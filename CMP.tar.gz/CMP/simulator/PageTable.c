#include <stdio.h>
#include "struct.h"
int cycle;
int num;
command comm[258];
data d[258];
PTE iPTE[1024];
PTE dPTE[1024];
int iTLBEntries;
int dTLBEntries;
int iPageTableEntries;
int dPageTableEntries;
int iMemEntries;
int dMemEntries;
int iCacheBlock;
int dCacheBlock;
int iPTMiss;
int iPTHit;
int dPTMiss;
int dPTHit;
MEM iMEM[1024];
MEM dMEM[1024];
int iniDisk;
int indDisk;
int iPageSize;

int Find_iPT(){
	//find PageTable
	int i;
	int VPN;
        if(num >= 2) VPN = comm[num].VPN;
        else VPN = PC/iPageSize;
	for(i=0;i<iPageTableEntries;i++){
		//PageTable hit
		if(iPTE[i].VPN == VPN && iPTE[i].valid == 1){
			iPTHit ++ ;
			iPTE[i].LRU = cycle;
			comm[num].PPN = i;
			return 1;
		}
	}
	//Page Fault
	iPTMiss ++;
	iniDisk = 1;
	return 0;
}

void New_iPT(){
	//Find for black space
	int i;
	int VPN;
        if(num >= 2) VPN = comm[num].VPN;
        else VPN = PC/iPageSize;
	for(i=0;i<iPageTableEntries;i++){
		//There is a space
		if(iPTE[i].valid == 0){
			iPTE[i].valid = 1;
			iPTE[i].VPN = VPN;
			iPTE[i].LRU = cycle;
			comm[num].PPN = i;
			return;
		}
	}
	//No space
	//Find a victim to replace
	int victim = 0;
	int min = iPTE[0].LRU;
	for(i=1;i<iPageTableEntries;i++){
		if(iPTE[i].LRU < min && iPTE[i].valid == 1){
			victim = i;
			min = iPTE[i].LRU;
		}
	}
	//Replace the victim out
	iPTE[victim].valid = 1;
	iPTE[victim].VPN = VPN;
	iPTE[victim].LRU = cycle;
	comm[num].PPN = victim;
	
}

int Find_dPT(int dnum){
	//find PageTable
        int i;
        for(i=0;i<dPageTableEntries;i++){
                //PageTable hit
                if(dPTE[i].VPN == d[dnum].VPN && dPTE[i].valid == 1){
                        dPTHit ++ ;
                        dPTE[i].LRU = cycle;
                        d[dnum].PPN = i;
                        return 1;
                }
        }
        //Page Fault
        dPTMiss ++;
        indDisk = 1;
//	printf("indDisk:%d\n",indDisk);
        return 0;
}

void New_dPT(int dnum){
	//Find for black space
        int i;
        for(i=0;i<dPageTableEntries;i++){
                //There is a space
                if(dPTE[i].valid == 0){
                        dPTE[i].valid = 1;
                        dPTE[i].VPN = d[dnum].VPN;
                        dPTE[i].LRU = cycle;
                        d[dnum].PPN = i;
                        return;
                }
        }
        //No space
        //Find a victim to replace
        int victim = 0;
        int min = dPTE[0].LRU;
        for(i=1;i<dPageTableEntries;i++){
                if(dPTE[i].LRU < min && dPTE[i].valid == 1){
                        victim = i;
                        min = dPTE[i].LRU;
                }
        }
        //Replace the victim out
        dPTE[victim].valid = 1;
        dPTE[victim].VPN = d[dnum].VPN;
        dPTE[victim].LRU = cycle;
        d[dnum].PPN = victim;
}
void New_iMem(){
	int i;
	int VPN;
        if(num >= 2) VPN = comm[num].VPN;
        else VPN = PC/iPageSize;
	for(i=0;i<iMemEntries;i++){
		//There is a space
		if(iMEM[i].valid == 0){
			iMEM[i].valid = 1;
			iMEM[i].LRU = cycle;
			iMEM[i].VPN = VPN;
			return;
		}
	}
	//No Space
	//Find a victim to replace
	int victim = 0 ;
	int min = iMEM[0].LRU;
	for(i=1;i<iMemEntries;i++){
		if(iMEM[i].LRU < min){
			victim = i;
			min = iMEM[i].LRU;
		}
	}
	//detele TLB, PageTable, Cache which has the same VPN as the victim
	for(i=0;i<iPageTableEntries;i++){
		if(iMEM[victim].VPN == iPTE[i].VPN && iPTE[i].valid == 1){
			iPTE[i].VPN = 0;
			iPTE[i].valid = 0;
			iPTE[i].LRU = 0;
			int j;
			for(j=0;j<iTLBEntries;j++){
				if(iMEM[victim].VPN == iTLB[j].VPN && iTLB[j].valid == 1){
					iTLB[j].valid = 0;
					iTLB[j].VPN = 0;
					iTLB[j].LRU = 0;
				}
			}
			int n;
			for(n=0;n<iCacheBlock;n++){
				if(iCH[n].VPN == iMEM[victim].VPN && iCH[n].valid == 1){
					iCH[n].valid = 0;
					iCH[n].VPN = 0;
					if(iCH[n].MRU == 1){
                                                iCH[dCH[n].set*iCacheWay].MRUnum --;
                                                iCH[n].MRU = 0;
                                        }
                                        iCH[n].MRU = 0;
                                        iCH[n].tag = 0;
				}
			}
		}
	}

	//refresh memory
	iMEM[victim].VPN = VPN;
	iMEM[victim].valid = 1;
	iMEM[victim].LRU = cycle;
}

void New_dMem(int dnum){
	int i;
        for(i=0;i<dMemEntries;i++){
                //There is a space
                if(dMEM[i].valid == 0){
                        dMEM[i].valid = 1;
                        dMEM[i].LRU = cycle;
			dMEM[i].VPN = d[dnum].VPN;
                        return;
                }
        }
        //No Space
        //Find a victim to replace
        int victim = 0 ;
        int min = dMEM[0].LRU;
        for(i=1;i<dMemEntries;i++){
                if(dMEM[i].LRU < min){
                        victim = i;
                        min = dMEM[i].LRU;
                }
        }
	//printf("replace victim VPN:%d\n",dMEM[victim].VPN);
	//detele TLB, PageTable, Cache which has the same VPN as the victim
        for(i=0;i<dPageTableEntries;i++){
                if(dMEM[victim].VPN == dPTE[i].VPN && dPTE[i].valid == 1){
                        dPTE[i].VPN = 0;
                        dPTE[i].valid = 0;
                        dPTE[i].LRU = 0;
                        int j;
                        for(j=0;j<dTLBEntries;j++){
                                if(dMEM[victim].VPN == dTLB[j].VPN && dTLB[j].valid == 1){
                                        dTLB[j].valid = 0;
                                        dTLB[j].VPN = 0;
                                        dTLB[j].LRU = 0;
                                }
                        }
                        int n;
                        for(n=0;n<dCacheBlock;n++){
                                if(dCH[n].VPN == dMEM[victim].VPN && dCH[n].valid == 1){
                                        dCH[n].valid = 0;
                                        dCH[n].VPN = 0;
					if(dCH[n].MRU == 1){
						dCH[dCH[n].set*dCacheWay].MRUnum --;
						dCH[n].MRU = 0;
					}
                                        dCH[n].MRU = 0;
					dCH[n].tag = 0;
                                }
                        }
                }
        }

        //refresh memory
        dMEM[victim].VPN = d[dnum].VPN;
        dMEM[victim].valid = 1;
        dMEM[victim].LRU = cycle;
}
