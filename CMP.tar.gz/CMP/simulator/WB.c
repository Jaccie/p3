#include <stdio.h>
#include "struct.h"

command comm[258];
int result;
int num;
int buff[32];

void WB(){
	//printf("WB num:%d\n",num);
	//printf("result:%d\n",result);
	if(num >= 2 && comm[num].nop == 0 && comm[num].RegWrite == 1){
		//rType except mult&multu
		if(comm[num].nop == 0 && comm[num].opcode == 0 && comm[num].func != 24 && comm[num].func != 25){
			if(comm[num].rd != 0)
				buff[comm[num].rd] = result;
		}
		//iType
		else if(comm[num].opcode == 8 || comm[num].opcode == 9 || comm[num].opcode == 35 || comm[num].opcode == 33 || comm[num].opcode == 37 || comm[num].opcode == 32 || comm[num].opcode == 36 || comm[num].opcode == 15 || comm[num].opcode == 12 || comm[num].opcode == 13 || comm[num].opcode == 14 || comm[num].opcode == 10){
			if(comm[num].rt != 0){
				buff[comm[num].rt] = result;
//				printf("reg[%d]:0x%08X\n",comm[num].rt,result);
			}
		}
		//jType
		else if(comm[num].opcode == 3){
			buff[31] = result;
		}
	}
}	
