#include <stdio.h>
#include "struct.h"

command comm[258];
data d[258];
int reg[32];
int Hi,Lo;
int num_of_instruction;
void read_file(){

    FILE* iimage = fopen("iimage.bin", "rb");
    FILE* dimage = fopen("dimage.bin", "rb");
    if(!iimage) printf("cannot open the iimage file...");
    else if(!dimage) printf("cannot open the dimage file...");
    else{
        unsigned int in[258],tmp,tmp2,tmp3,tmp4,k;
        fread (&in,sizeof(unsigned int),258,iimage);
        tmp  =  in[1] << 24 ;
        tmp2 = ((in[1]  << 16) >> 24)<<16;
        tmp3 = ((in[1]  << 8) >> 24)<<8;
        tmp4 = in[1]  >> 24;
        k = tmp + tmp2 + tmp3 + tmp4 ;
        int i;
	num_of_instruction = k;
	//printf("K=%d\n",k);
        for(i = 0 ; i < k+2 ; i++){
            tmp  =  in[i] << 24 ;
            tmp2 = ((in[i]  << 16) >> 24) << 16;
            tmp3 = ((in[i]  << 8) >> 24) << 8;
            tmp4 = in[i]  >> 24;
            in[i] = tmp + tmp2 + tmp3 + tmp4 ;
            if(i==0){ comm[i].address = in[i];comm[i].instruction = 0;}
	    else{ comm[i].address = comm[0].address + 4*(i-2);
            comm[i].i = i;
            comm[i].instruction = in[i];
	    comm[i].VPN = comm[i].address/iPageSize;
	    comm[i].offset = comm[i].address%iPageSize;}
 //           printf("i = %d , 0x%08x Address: %08x, VPN= %d, offset= %d\n",i,comm[i].instruction,comm[i].address,comm[i].VPN,comm[i].offset);
        }
	PC = comm[0].address;
	comm[0].name = "sll";
	comm[1].name = "sll";

	unsigned int in_d[258];
	fread(&in_d,sizeof(unsigned int),258,dimage);
	tmp = in_d[1] << 24;
	tmp2 = ((in_d[1] << 16) >> 24) << 16;
	tmp3 = ((in_d[1] << 8) >> 24) << 8;
	tmp4 = in_d[1] >> 24;
	k = tmp + tmp2 + tmp3 + tmp4;
	for(i = 0 ; i < k+2 ; i++){
		tmp = in_d[i] << 24;
		tmp2 = ((in_d[i]  << 16) >> 24) << 16;
            	tmp3 = ((in_d[i]  << 8) >> 24) << 8;
            	tmp4 = in_d[i]  >> 24;
            	in_d[i] = tmp + tmp2 + tmp3 + tmp4 ;
		if(i==0){ 
			reg[29] = in_d[i];
			d[0].address = in_d[i];
		}
		else d[i].address = d[0].address + (i-2)*4;
		d[i].value = in_d[i];
		d[i].VPN = d[i].address/dPageSize;
		d[i].offset = d[i].address%dPageSize;
		/*printf("i = %d , 0x%08x Address: %d ",i,d[i].value,d[i].address);
		printf("VPN %d\n",d[i].VPN);
	*/}
/*	i = k+2;
	while(i<258){
		d[i].address = d[0].address + (i-2)*4;
		d[i].VPN = d[i].address/dPageSize;	
	}*/
   }
}


