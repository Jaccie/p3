#include <stdio.h>
#include "struct.h"
int cycle;
command comm[258];
data d[258];
CH iCH[1024];
CH dCH[1024];
FILE* trace;

int num;
int iPageSize;
int iCacheBlock;
int iCacheSet;
int iCacheWay;
int iCHHit;
int iCHMiss;
int iMruNum;
int dCacheBlock;
int dCacheSet;
int dCacheWay;
int dCHHit;
int dCHMiss;
int dMruNum;
int iniDisk;
int indDisk;
int result;
unsigned int PC;

void iCache(){

	int VPN;
	int set;
	int tag;
        if(num >= 2){
 		set = (num-2) % iCacheSet;
		tag = num-2;
		VPN = comm[num].VPN;
	}
        else{
	 	set = ((PC-comm[0].address)/4) % iCacheSet;
		tag = (PC-comm[0].address)/4;
		VPN = PC/iPageSize;
	}
	int i = iCacheWay * set;

	if(iniDisk == 0){
		for(; i<iCacheWay * (set+1); i++){
			//Cache hit
                        if(iCH[i].tag == tag && iCH[i].valid == 1){
                                iCHHit ++;
                                fprintf(trace, " ICache ");
                                //check for MRU
                                if(iCH[i].MRU == 0){
                                        if(iCH[iCacheWay*set].MRUnum == iCacheWay-1){
                                                for(int j=iCacheWay*set;j<iCacheWay*(set+1);j++) iCH[j].MRU = 0;
                                                iCH[iCacheWay*set].MRUnum = 1;
                                        }
                                        else iCH[iCacheWay*set].MRUnum ++;
					iCH[i].MRU = 1;
                                }
                                iCH[i].VPN = VPN;
                                return;
                        }

		}
	}
	//Cache miss
	iCHMiss ++;
	//Replace
	for(i=iCacheWay*set;i<iCacheWay * (set+1); i++){
		if(iCH[i].MRU == 0){
			//printf("%d MRU=0\n",i);
			iCH[i].tag = tag;
			iCH[i].valid = 1;
			iCH[i].VPN = VPN;
			//check for MRU
			if(iCH[iCacheWay*set].MRUnum == iCacheWay-1){
                                for(int j=iCacheWay*set;j<iCacheWay*(set+1);j++) iCH[j].MRU = 0;
                                iCH[iCacheWay*set].MRUnum = 1;
                        }
                        else{
                                iCH[iCacheWay*set].MRUnum ++;
                        }
			iCH[i].MRU = 1;
                        break;
		}
	}
	if(iCacheWay == 1){
                iCH[set].tag = tag;
                iCH[set].MRU = 1;
        }
}

void dCache(int dnum){
	//in which set
	int tag = (d[dnum].address-d[0].address)/4;
	int set = tag % dCacheSet;
//	printf("dnum %d tag:%d set:%d\n",dnum,tag,set);
        //int tag = comm[num].PA / iCacheSet;
        //printf("%d !!!!!!!!!!inCache, set %d ,tag%d, PA %d\n",num,set,tag,comm[num].PA);
        //the start of this set
        int i = dCacheWay * set;
        if(indDisk == 0){
                for(; i<dCacheWay * (set+1); i++){
                        //Cache hit
                        if(dCH[i].tag == tag && dCH[i].valid == 1){
                                dCHHit ++;
                                fprintf(trace, " DCache ");
				//check for MRU
				if(dCH[i].MRU == 0){
					if(dCH[dCacheWay*set].MRUnum == dCacheWay-1){
                                		for(int j=dCacheWay*set;j<dCacheWay*(set+1);j++) dCH[j].MRU = 0;
                                		dCH[dCacheWay*set].MRUnum = 1;
					}
					else dCH[dCacheWay*set].MRUnum ++;
					dCH[i].MRU = 1;
				}
				dCH[i].VPN = d[dnum].VPN;
                                return;
                        }
                }
        }
        //Cache miss
        dCHMiss ++;
        //Replace
        for(i=dCacheWay*set;i<dCacheWay * (set+1); i++){
                if(dCH[i].MRU == 0){
  //                      printf("CacheMiss!!!!");
                        dCH[i].valid = 1;
                        dCH[i].tag = tag;
			dCH[i].VPN = d[dnum].VPN;
                        //check for MRU
                        if(dCH[dCacheWay*set].MRUnum == dCacheWay-1){
                                for(int j=dCacheWay*set;j<dCacheWay*(set+1);j++) dCH[j].MRU = 0;
                                dCH[dCacheWay*set].MRUnum = 1;
                                dCH[i].MRU = 1;
                        }
                        else{
                                dCH[dCacheWay*set].MRUnum ++;
                                dCH[i].MRU = 1;
                        }
                        break;
                }
        }
	if(dCacheWay == 1){
		dCH[set].tag = tag;
		dCH[set].MRU = 1;
		dCH[set].VPN = d[dnum].VPN;
	}
}
