#include <stdio.h>
int isHalt;

void halt(){
	isHalt = 1;
	printf("!!!!!!Halt!!!!!!!!!\n");
}
